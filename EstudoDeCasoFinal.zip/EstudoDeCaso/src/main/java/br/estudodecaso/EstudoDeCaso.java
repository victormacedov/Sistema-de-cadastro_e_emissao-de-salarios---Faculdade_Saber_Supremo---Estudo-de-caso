/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.estudodecaso;

/**
 *
 * @author Victor Macedo
 */
public class EstudoDeCaso {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
